<?php
class Modelo{
    function __construct(){
        //constructor clase modelo
        
    }
}
?>