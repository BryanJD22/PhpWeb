<?php
    class Controlador{
        function __construct(){
            //constructor

        }


    }


?>